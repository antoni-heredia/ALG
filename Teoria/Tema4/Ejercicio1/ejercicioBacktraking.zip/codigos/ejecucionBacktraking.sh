echo "Ejecutando script backtraking 1"
./script_backtraking1.sh
echo "Ejecutando script backtraking 2"
./script_backtraking2.sh